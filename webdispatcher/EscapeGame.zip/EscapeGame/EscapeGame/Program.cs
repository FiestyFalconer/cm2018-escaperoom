﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EscapeGame
{
    class Program
    {
        static void Main(string[] args)
        {
            int nbCable = 5;
            int firstCable = 1;
            int secondeCable = 1;
            int lastCable = 1;
            int doublon = 0;
            List<int[]> maListe = new List<int[]>();
            List<int> maSomme = new List<int>();

            Random rnd = new Random();
            Console.WriteLine("INSERT INTO `gameset` (`cableSelect1`, `cableSelect2`, `cableSelect3`, `indice1`, `indice2`, `binary`)");
            Console.Write("VALUES ");

            for (int f = 0; f < nbCable; f++)
            {
                for (int s = 0; s < nbCable; s++)
                {
                    for (int l = 0; l < nbCable; l++)
                    {
                        if (f != s && s != l && f != l)
                        {
                            string soluceOne = rnd.Next(8, 15).ToString("X");
                            string soluceTwo = rnd.Next(0, 15).ToString("X");
                            string binary = Convert.ToString(Convert.ToInt32(soluceOne+ soluceTwo, 16), 2);
                            /*
                            doublon = 0;
                            for (int i = 0; i < maSomme.Count; i++)
                            {
                                if (maSomme[i] == f + s + l)
                                    doublon = 1;
                            }
                            if (doublon != 1)
                            {*/
                            Console.WriteLine("('" + (firstCable + f) + "', '" + (secondeCable + s) + "', '" + (lastCable + l) + "', '" + soluceOne + "', '" + soluceTwo + "', '"+ binary + "'),");
                               /* maListe.Add(new int[] { f, s, l });
                                maSomme.Add(f + s + l);
                            }*/
                        }
                    }
                }
            }
        }
    }
}
